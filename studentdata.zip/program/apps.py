from django.apps import AppConfig


class SchoolprogramConfig(AppConfig):
    name = 'program'

