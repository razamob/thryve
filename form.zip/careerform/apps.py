from django.apps import AppConfig


class CareerformConfig(AppConfig):
    name = 'careerform'
