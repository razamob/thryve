from django.apps import AppConfig


class DataAnalysisConfig(AppConfig):
    name = 'data_analysis'
