from django.apps import AppConfig


class EmploymentformConfig(AppConfig):
    name = 'employmentform'
