from django.apps import AppConfig


class ProgramConfig(AppConfig):
    name = 'program'
